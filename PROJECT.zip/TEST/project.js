//animation
function first() {
    document.getElementById("slide-image").src="pharma2.jpg";
 }
 function second() {
     document.getElementById("slide-image").src="pharma3.jpg";
  }
  function third() {
    document.getElementById("slide-image").src="pharma1.jpg";
 }
  
 
  setInterval(first,2000);
  setInterval(second,4000);
  setInterval(third,6000);
 
  
  